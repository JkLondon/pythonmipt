import turtle

turtle.shape('turtle')
for i in range(360):
	turtle.forward(1)
	turtle.left(1)
	
