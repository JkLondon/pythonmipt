import turtle as t
nd=90
for i in range(10,1000,10):
	for j in range(2):
		t.forward(i)
		t.left(nd)

