import turtle

for i in range(4):
	turtle.forward(10)
	turtle.left(90)
