from pyrob.samples import demo1, demo2, demo3, demo4
from pyrob.api import  run_tasks

run_tasks()